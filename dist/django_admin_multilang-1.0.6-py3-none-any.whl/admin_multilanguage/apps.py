from django.apps import AppConfig


class LanguagesConfig(AppConfig):
    name = 'admin_multilanguage'
